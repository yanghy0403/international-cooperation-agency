<template>
  <div class="globalMap">
    <div class="titleDiv">
      <div class="titleName">全球地域分布</div>
      <div class="operating">
        <span class="iconfont icon-xiazai" @click="download"></span>
        <span class="iconfont icon-quanping" @click="handleChange"></span>
      </div>
    </div>
    <div class="worldMap" ref="worldMap" id="mapDiv"></div>
    <div class="personDiv">
      <div class="personTitle">人员国家分布</div>
      <div class="titleName">
        <span>国家</span>
        <span>数量/人</span>
      </div>
      <div class="personCountry" ref="personCountry"></div>
    </div>
    <transition name="bounce" mode="out-in">
      <div class="fullFcreen" v-if="!change">
        <div class="titleDiv">
          <div class="titleName">全球地域分布</div>
          <div class="operating">
            <span class="iconfont icon-xiazai" @click="download"></span>
            <span class="iconfont icon-quanping" @click="handleChange"></span>
          </div>
        </div>
        <div class="worldMap" ref="worldMap" id="mapDiv"></div>
      </div>
    </transition>
  </div>
</template>

<script>
import word from "../../../assets/js/world";
export default {
  data() {
    return {
      change: true,
      clientHeight: ""
    };
  },
  mounted() {
    this.clientHeight = `${document.documentElement.clientHeight}`; //获取浏览器可视区域高度
    let that = this;
    window.onresize = function() {
      that.clientHeight = `${document.documentElement.clientHeight}`;
    };
    this.$nextTick(() => {
      this.handleWorldMap();
      this.handlePersonCountry();
    });
  },
  methods: {
    handleChange() {
      this.change = !this.change;
      let time = setTimeout(() => {
        if (!this.change) {
          this.$refs.worldMap.style.height = this.clientHeight - 250 + "px";
        } else {
          this.$refs.worldMap.style.height = 300 + "px";
        }
        this.handleWorldMap();
        this.handlePersonCountry();
        clearTimeout(time);
      }, 100);
    },
        download() {
     var myChart = this.$echarts.init(this.$refs.worldMap);
      var i = myChart.getDataURL({
        type: "png",
        backgroundColor: "white",
        pixelRatio: 2,
        // 导出的图片分辨率比例，默认为 1。
        //pixelRatio: number,
      });
      var $a = document.createElement("a");
      $a.setAttribute("href", i);
      $a.setAttribute("download", "全球分布.png");
      $a.click();
    },
    handleWorldMap() {
      var myChart = this.$echarts.init(this.$refs.worldMap),
        _this = this;
      myChart.showLoading();
      var data = [
        {
          name: "尼日利亚",
          value: 910
        },
        {
          name: "美国洛杉矶",
          value: 230
        },
        {
          name: "香港邦泰",
          value: 310
        },
        {
          name: "美国芝加哥",
          value: 230
        },
        {
          name: "加纳库马西",
          value: 510
        },
        {
          name: "英国曼彻斯特",
          value: 310
        },
        {
          name: "德国汉堡",
          value: 620
        },
        {
          name: "哈萨克斯坦阿拉木图",
          value: 20
        },
        {
          name: "俄罗斯伊尔库茨克",
          value: 810
        },
        {
          name: "巴西",
          value: 350
        },
        {
          name: "埃及达米埃塔",
          value: 350
        },
        {
          name: "西班牙巴塞罗纳",
          value: 350
        },
        {
          name: "柬埔寨金边",
          value: 350
        },
        {
          name: "意大利米兰",
          value: 350
        },
        {
          name: "莫桑比克马普托",
          value: 350
        },
        {
          name: "阿尔及利亚阿尔及尔",
          value: 350
        },
        {
          name: "阿联酋迪拜",
          value: 350
        },
        {
          name: "匈牙利布达佩斯",
          value: 350
        },
        {
          name: "澳大利亚悉尼",
          value: 350
        },
        {
          name: "美国加州",
          value: 350
        },
        {
          name: "澳大利亚墨尔本",
          value: 350
        },
        {
          name: "墨西哥",
          value: 350
        },
        {
          name: "加拿大温哥华",
          value: 350
        },
        {
          name: "上海",
          value: 450
        }
      ];
      var geoCoordMap = {
        上海: [121.4648, 31.2891],
        美国洛杉矶: [-118.24311 + 360, 34.052713],
        美国芝加哥: [-87.801833 + 360, 41.870975],
        加纳库马西: [-4.62829, 7.72415],
        英国曼彻斯特: [-1.657222, 51.886863],
        德国汉堡: [10.01959, 54.38474],
        哈萨克斯坦阿拉木图: [45.326912, 41.101891],
        俄罗斯伊尔库茨克: [89.116876, 67.757906],
        巴西: [-48.678945 + 360, -10.493623],
        埃及达米埃塔: [31.815593, 31.418032],
        西班牙巴塞罗纳: [2.175129, 41.385064],
        柬埔寨金边: [104.88659, 11.545469],
        意大利米兰: [9.189948, 45.46623],
        阿尔及利亚阿尔及尔: [3.054275, 36.753027],
        阿联酋迪拜: [55.269441, 25.204514],
        匈牙利布达佩斯: [17.108519, 48.179162],
        澳大利亚悉尼: [150.993137, -33.675509],
        美国加州: [-121.910642 + 360, 41.38028],
        澳大利亚墨尔本: [144.999416, -37.781726],
        墨西哥: [-99.094092 + 360, 19.365711],
        加拿大温哥华: [-123.023921 + 360, 49.311753]
      };
      var convertData = function(data) {
        var res = [];
        for (var i = 0; i < data.length; i++) {
          var geoCoord = geoCoordMap[data[i].name];
          if (geoCoord) {
            res.push({
              name: data[i].name,
              value: geoCoord.concat(data[i].value)
            });
          }
        }
        return res;
      };

      let option = {
        backgroundColor: "#a4aec2",
        tooltip: {
          trigger: "item"
        },
        geo: {
          map: "world",
          zoom: 3,
          label: {
            emphasis: {
              show: true
            }
          },
          layoutCenter: ["100%", "80%"], //地图位置
          layoutSize: "180%",
          roam: true,
          itemStyle: {
            normal: {
              areaColor: "#bcc3d1",
              borderColor: "#75808f"
            },
            emphasis: {
              areaColor: "#ff3a25",
              opacity: 0.5
            }
          }
        },
        series: [
          {
            type: "scatter",
            map: "world",
            coordinateSystem: "geo",
            data: convertData(data),
            rippleEffect: {
              period: 4, //动画时间，值越小速度越快
              brushType: "stroke", //波纹绘制方式 stroke, fill
              scale: 3 //波纹圆环最大限制，值越大波纹越大
            },
            symbolSize: function(val) {
              return val[2] / 20;
            },
            label: {
              normal: {
                formatter: "{b}",
                position: "right",
                show: false
              },
              emphasis: {
                show: true
              }
            },
            itemStyle: {
              normal: {
                color: "#ff3a25",
                shadowBlur: 5,
                shadowColor: "#333",
                opacity: 0.8
              }
            }
          },
          {
            type: "effectScatter",
            coordinateSystem: "geo",
            data: convertData(data),
            symbol: "circle",
            symbolSize: function(val) {
              return val[2] / 20;
            },
            showEffectOn: "render",
            rippleEffect: {
              period: 4, //动画时间，值越小速度越快
              brushType: "stroke", //波纹绘制方式 stroke, fill
              scale: 3 //波纹圆环最大限制，值越大波纹越大
            },
            hoverAnimation: true,
            label: {
              normal: {
                formatter: "{b}",
                position: "bottom",
                show: false
              }
            },
            itemStyle: {
              normal: {
                color: "#ff3a25",
                shadowBlur: 5,
                shadowColor: "#333",
                opacity: 0.8
              }
            },
            zlevel: 1
          }
        ]
      };
      myChart.setOption(option);
      myChart.hideLoading();
    },
    handlePersonCountry() {
      var myCharts = this.$echarts.init(this.$refs.personCountry),
        _this = this;
      myCharts.showLoading();

      var curInt = null;
      let option = {
        tooltip: {
          show: false
        },
        legend: {
          show: false
        },
        grid: {
          left: 170,
          top: 5
        },
        xAxis: {
          type: "value",

          splitLine: {
            show: false
          },
          axisLabel: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            show: false
          }
        },
        yAxis: {
          type: "category",
          inverse: true,
          axisLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisPointer: {
            label: {
              show: false,
              margin: 30
            }
          },
          data: [
            "杭州市",
            "宁波市",
            "温州市",
            "湖州市",
            "嘉兴市",
            "绍兴市",
            "金华市",
            "衢州市",
            "舟山市",
            "台州市",
            "丽水市"
          ],
          axisLabel: {
            margin: 150,
            fontSize: 14,
            align: "left",
            color: "#333"
          }
        },
        series: [
          {
            z: 2,
            name: "value",
            type: "bar",
            data: [66, 86, 82, 18, 153, 147, 13, 125, 11, 102, 100],
            itemStyle: {
              normal: {
                color: function(params) {
                  var key = params.dataIndex;
                  if (key === curInt) {
                    return "#ff3a25";
                  } else {
                    return "#a4aec2";
                  }
                }
              }
            },
            label: {
              show: true,
              position: "left",
              color: "#030303",
              fontSize: 14,
              offset: [-15, 0]
            }
          }
        ]
      };
      myCharts.setOption(option);
      myCharts.hideLoading();
      myCharts.on("click", function eConfig(params) {
        curInt = params.dataIndex;
        myCharts.setOption(option);
      });
    }
  }
};
</script>

<style lang="less" scoped>
.globalMap {
  width: 100%;
  height: 100%;
  padding: 10px 20px;
  .titleDiv {
    height: 22px;
    margin-bottom: 10px;
    .titleName {
      float: left;
      font-size: 20px;
      line-height: 22px;
      color: #191919;
      font-weight: 600;
    }
    .operating {
      float: right;
      span {
        display: inline-block;
        width: 22px;
        height: 22px;
        line-height: 22px;
        background: #d3d6dd;
        text-align: center;
        margin-right: 4px;
        font-weight: bold;
        color: #8f949f;
      }
      .chartActive {
        background: #ff3925;
        color: #fff;
      }
    }
  }
  .worldMap {
    float: left;
    width: 940px;
    height: 90%;
    // border: 1px solid #000;
  }
  .personDiv {
    width: 390px;
    height: 90%;
    overflow: hidden;
    border: solid 1px #d3d6dd;
    .personTitle {
      width: 100%;
      height: 40px;
      background: #e2e6ed;
      text-align: center;
      line-height: 40px;
      color: #191919;
      font-size: 14px;
      border-bottom: solid 1px #d3d6dd;
    }
    .titleName {
      width: 389px;
      height: 30px;
      background: #e8ebef;
      span {
        display: inline-block;
        line-height: 30px;
        font-size: 12px;
        color: #6f6f6f;
      }
      span:first-child {
        width: 25%;
        margin-left: 20px;
      }
    }
    .personCountry {
      width: 100%;
      height: 90%;
    }
  }
  .fullFcreen {
    position: absolute;
    top: 40px;
    left: 20px;
    width: 1370px;
    height: 91%;
    padding: 5%;
    background: #fff;
    z-index: 2;
    .worldMap {
      float: left;
      width: 100%;
      height: 90%;
      // border: 1px solid #000;
    }

    .bounce-enter-active {
      animation: bounce-in 6s;
    }
    .bounce-leave-active {
      animation: bounce-in 6s reverse;
    }
    @keyframes bounce-in {
      0% {
        transform: scale(0);
      }
      50% {
        transform: scale(1.5);
      }
      100% {
        transform: scale(1);
      }
    }
    .subsidizeList {
      width: 100%;
    }
  }
}
</style>