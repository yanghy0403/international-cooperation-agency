<template>
  <div class="subsidize">
    <div class="titleDiv">
      <div class="titleName">历年资助情况</div>
      <div class="operating">
        <span class="iconfont icon-xiazai" @click="download"></span>
        <span @click="chart=0" :class="{chartActive:chart==0}" class="iconfont icon-tongji"></span>
        <span @click="chart=1" :class="{chartActive:chart==1}" class="iconfont icon-liebiao"></span>
        <span class="iconfont icon-quanping" @click="handleChange"></span>
      </div>
    </div>
    <div class="subsidizeCharts" v-show="chart==0">
      <div class="subsidizeChart" ref="mySubsidizeChart"></div>
    </div>
    <div id="subsidizeList" v-show="chart==1">
      <table>
        <thead>
          <tr>
            <th>年份</th>
            <th>博士后</th>
            <th>访问学者</th>
            <th>杰出学者</th>
            <th>特需人才</th>
            <th>外国青年学者</th>
            <th>总计</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item,i) in foundingData.tableData" :key="i">
            <td>{{item.year}}</td>
            <td>{{item.博士后}}</td>
            <td>{{item.访问学者}}</td>
            <td>{{item.杰出学者}}</td>
            <td>{{item.特需人才}}</td>
            <td>{{item.外国青年学者}}</td>
            <td>{{item.总计}}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <transition name="bounce" mode="out-in">
      <div class="fullFcreen" v-if="!change">
        <div class="titleDiv">
          <div class="titleName">历年资助情况</div>
          <div class="operating">
            <span class="iconfont icon-xiazai" @click="download"></span>
            <span @click="chart=0" :class="{chartActive:chart==0}" class="iconfont icon-tongji"></span>
            <span @click="chart=1" :class="{chartActive:chart==1}" class="iconfont icon-liebiao"></span>
            <span class="iconfont icon-quanping" @click="handleChange"></span>
          </div>
        </div>
        <div class="subsidizeCharts" v-if="chart==0">
          <div class="subsidizeChart" ref="mySubsidizeChart"></div>
        </div>
        <div id="subsidizeList" v-if="chart==1">
          <table>
            <thead>
              <tr>
                <th>年份</th>
                <th>博士后</th>
                <th>访问学者</th>
                <th>杰出学者</th>
                <th>特需人才</th>
                <th>外国青年学者</th>
                <th>总计</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item,i) in foundingData.tableData" :key="i">
                <td>{{item.year}}</td>
                <td>{{item.博士后}}</td>
                <td>{{item.访问学者}}</td>
                <td>{{item.杰出学者}}</td>
                <td>{{item.特需人才}}</td>
                <td>{{item.外国青年学者}}</td>
                <td>{{item.总计}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
export default {
  data() {
    return {
      change: true,
      chart: 0,
      show: false,
      clientHeight: "",
      foundingData: [],
      mySubsidizeChart: null
    };
  },
  props: ["data"],
  watch: {
    chart(val) {
      if (val !== 1) {
        this.$nextTick(() => {
          this.handleSubsidizeChart();
        });
      }
    },
    data(val) {
      this.foundingData = val;
      this.handleSubsidizeChart();
    }
  },
  mounted() {
    this.foundingData = this.data;
    this.clientHeight = `${document.documentElement.clientHeight}`; //获取浏览器可视区域高度
    let that = this;
    window.onresize = function() {
      that.clientHeight = `${document.documentElement.clientHeight}`;
    };
    this.$nextTick(() => {
      this.handleSubsidizeChart();
    });
  },
  methods: {
    handleChange() {
      this.change = !this.change;
      let time = setTimeout(() => {
        if (!this.change) {
          this.$refs.mySubsidizeChart.style.height =
            this.clientHeight - 250 + "px";
        } else {
          this.$refs.mySubsidizeChart.style.height = 300 + "px";
        }
        this.handleSubsidizeChart();
        clearTimeout(time);
      }, 100);
    },
    // 下载图片
    download() {
     var myChart = this.$echarts.init(this.$refs.mySubsidizeChart);
      var i = myChart.getDataURL({
        type: "png",
        backgroundColor: "white",
        pixelRatio: 2,
        // 导出的图片分辨率比例，默认为 1。
        //pixelRatio: number,
      });
      var $a = document.createElement("a");
      $a.setAttribute("href", i);
      $a.setAttribute("download", "历年资助.png");
      $a.click();
    },
    handleSubsidizeChart() {
      var myChart = this.$echarts.init(this.$refs.mySubsidizeChart),
        _this = this;
      myChart.showLoading();
      let option = {
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
            textStyle: {
              color: "#fff"
            }
          }
        },
        grid: {
          left: 150,
          top: 30,
          right: 5,
          bottom: 20
        },
        legend: {
          type: "scroll",
          orient: "vertical",
          left: "0",
          itemGap: 24,
          align: "left",
          top: "middle",
          itemWidth: 12,
          itemHeight: 6,
          textStyle: {
            color: "#191919"
          },
          data: this.foundingData.legendData
        },

        calculable: true,
        xAxis: [
          {
            type: "category",
            axisLine: {
              lineStyle: {
                color: "#90979c"
              }
            },
            splitLine: {
              show: false
            },
            axisTick: {
              show: false
            },
            splitArea: {
              show: false
            },
            axisLabel: {
              interval: 0
            },
            data: this.foundingData.xAxisData
          }
        ],
        yAxis: {
          interval: 50,
          type: "value",
          axisLine: {
            show: false,
            lineStyle: {
              color: "#262626"
            }
          },
          splitLine: {
            show: true
            // lineStyle: {
            //   color: "#262626"
            // }
          },
          axisLabel: {}
        },
        series: [
          {
            name: "博士后",
            type: "bar",
            stack: "总量",
            barMaxWidth: 46,
            barGap: "1%",
            itemStyle: {
              normal: {
                color: "#496081",
                label: {
                  show: true,
                  textStyle: {
                    color: "#fff"
                  },
                  position: "inside"
                  // formatter: function(p) {
                  //     return p.value > 0 ? (p.value) : '';
                  // }
                }
              }
            },
            data: this.foundingData.yAxisData1
          },

          {
            name: "访问学者",
            type: "bar",
            stack: "总量",
            itemStyle: {
              normal: {
                color: "#899ab3",
                barBorderRadius: 0,
                label: {
                  show: true,
                  position: "inside",
                  formatter: function(p) {
                    return p.value > 0 ? p.value : "";
                  }
                }
              }
            },
            data: this.foundingData.yAxisData2
          },
          {
            name: "杰出学者",
            type: "bar",
            stack: "总量",
            itemStyle: {
              normal: {
                color: "#c5aa9a",
                barBorderRadius: 0,
                label: {
                  show: true,
                  position: "inside",
                  formatter: function(p) {
                    return p.value > 0 ? p.value : "";
                  }
                }
              }
            },
            data: this.foundingData.yAxisData3
          },
          {
            name: "特需人才",
            type: "bar",
            stack: "总量",
            itemStyle: {
              normal: {
                color: "#d76459",
                barBorderRadius: 0,
                label: {
                  show: true,
                  position: "inside",
                  formatter: function(p) {
                    return p.value > 0 ? p.value : "";
                  }
                }
              }
            },
            data: this.foundingData.yAxisData4
          },
          {
            name: "外国青年学者",
            type: "bar",
            stack: "总量",
            itemStyle: {
              normal: {
                color: "#89b397",
                barBorderRadius: 0,
                label: {
                  show: true,
                  position: "inside",
                  formatter: function(p) {
                    return p.value > 0 ? p.value : "";
                  }
                }
              }
            },
            data: this.foundingData.yAxisData5
          }
        ]
      };
      myChart.setOption(option, true);
      myChart.hideLoading();
    }
  }
};
</script>

<style lang="less" scoped>
.subsidize {
  width: 100%;
  height: 100%;
  padding: 20px;
  .titleDiv {
    height: 22px;
    .titleName {
      float: left;
      font-size: 20px;
      line-height: 22px;
      color: #191919;
      font-weight: 600;
    }
    .operating {
      float: right;
      span {
        display: inline-block;
        width: 22px;
        height: 22px;
        line-height: 22px;
        background: #d3d6dd;
        text-align: center;
        margin-right: 4px;
        font-weight: bold;
        color: #8f949f;
      }
      .chartActive {
        background: #ff3925;
        color: #fff;
      }
    }
  }
  .subsidizeCharts {
    width: 100%;
    height: 330px;
    .subsidizeChart {
      width: 100%;
      height: 100%;
    }
  }
  #subsidizeList {
    margin-top: 20px;
    width: 100%;
    // height: 00px;
    border: 1px solid #ccc;
    table {
      width: 100%;
      thead {
        tr {
          height: 25px;
          line-height: 0px;
          th {
            font-size: 12px;
            width: 10%;
            text-align: center;
          }
        }
      }
      tbody {
        tr {
          border-top: 1px solid #ccc;
          height: 25px;
          line-height: 0px;
          td {
            width: 10%;
            text-align: center;
          }
        }
      }
    }
  }
  .fullFcreen {
    position: absolute;
    top: 40px;
    left: 20px;
    width: 1370px;
    height: 91%;
    padding: 5%;
    background: #fff;
    z-index: 2;
    .subsidizeCharts {
      width: 100%;
      height: 91%;
      .subsidizeChart {
        width: 100%;
        height: 100%;
      }
    }
    #subsidizeList {
      margin-top: 20px;
      width: 100%;
      // height: 00px;
      border: 1px solid #ccc;
      table {
        width: 100%;
        thead {
          tr {
            height: 50px;
            line-height: 0px;
            th {
              font-size: 12px;
              width: 10%;
              text-align: center;
            }
          }
        }
        tbody {
          tr {
            border-top: 1px solid #ccc;
            height: 50px;
            line-height: 0px;
            td {
              width: 10%;
              text-align: center;
            }
          }
        }
      }
    }
    .bounce-enter-active {
      animation: bounce-in 6s;
    }
    .bounce-leave-active {
      animation: bounce-in 6s reverse;
    }
    @keyframes bounce-in {
      0% {
        transform: scale(0);
      }
      50% {
        transform: scale(1.5);
      }
      100% {
        transform: scale(1);
      }
    }
    .subsidizeList {
      width: 100%;
    }
  }
}
</style>