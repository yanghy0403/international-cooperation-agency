<template>
  <div class="areas">
    <div class="titleDiv">
      <div class="titleName">学科领域分布</div>
      <div class="operating">
        <span class="iconfont icon-xiazai"></span>
        <span @click="chart=0" :class="{chartActive:chart==0}" class="iconfont icon-tongji"></span>
        <span @click="chart=1" :class="{chartActive:chart==1}" class="iconfont icon-liebiao"></span>
        <span class="iconfont icon-quanping" @click="handleChange"></span>
      </div>
    </div>
    <div class="areasCharts" v-show="chart==0">
      <div class="areasChart" ref="mySubsidizeChart"></div>
      <div class="clickAreasChart" ref="clickAreasChart"></div>
    </div>
    <div id="subjectAreasList" v-show="chart==1">
      <table>
        <thead>
          <tr>
            <th>年份</th>
            <th>博士后</th>
            <th>访问学者</th>
            <th>杰出学者</th>
            <th>特需人才</th>
            <th>外国青年学者</th>
            <th>总计</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>2013</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2014</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2015</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2016</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2017</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2018</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2019</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
          <tr>
            <td>2020</td>
            <td>90</td>
            <td>202</td>
            <td>20</td>
            <td>0</td>
            <td>0</td>
            <td>312</td>
          </tr>
        </tbody>
      </table>
    </div>
    <transition name="bounce" mode="out-in">
      <div class="fullFcreen" v-if="!change">
        <div class="titleDiv">
          <div class="titleName">学科领域分布</div>
          <div class="operating">
            <span class="iconfont icon-xiazai"></span>
            <span @click="chart=0" :class="{chartActive:chart==0}" class="iconfont icon-tongji"></span>
            <span @click="chart=1" :class="{chartActive:chart==1}" class="iconfont icon-liebiao"></span>
            <span class="iconfont icon-quanping" @click="handleChange"></span>
          </div>
        </div>
        <div class="areasCharts" v-if="chart==0">
          <div class="areasChart" ref="mySubsidizeChart"></div>
          <div class="clickAreasChart" ref="clickAreasChart"></div>
        </div>
        <div id="subjectAreasList" v-if="chart==1">
          <table>
            <thead>
              <tr>
                <th>年份</th>
                <th>博士后</th>
                <th>访问学者</th>
                <th>杰出学者</th>
                <th>特需人才</th>
                <th>外国青年学者</th>
                <th>总计</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>2013</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2014</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2015</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2016</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2017</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2018</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2019</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
              <tr>
                <td>2020</td>
                <td>90</td>
                <td>202</td>
                <td>20</td>
                <td>0</td>
                <td>0</td>
                <td>312</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </transition>
  </div>
</template> 
<script>
export default {
  data() {
    return {
      change: true,
      chart: 0,
      colorVal: "",
      clientHeight: ""
    };
  },
  watch: {
    chart(val) {
      if (val == 0) {
        this.$nextTick(() => {
          this.handleSubjectAreas();
        });
      }
    }
  },
  mounted() {
    this.clientHeight = `${document.documentElement.clientHeight}`; //获取浏览器可视区域高度
    let that = this;
    window.onresize = function() {
      that.clientHeight = `${document.documentElement.clientHeight}`;
    };
    this.$nextTick(() => {
      this.handleSubjectAreas();
    });
  },
  methods: {
    handleChange() {
      this.change = !this.change;
      let time = setTimeout(() => {
        if (!this.change) {
          this.$refs.mySubsidizeChart.style.height =
            this.clientHeight - 250 + "px";
        } else {
          this.$refs.mySubsidizeChart.style.height = 300 + "px";
        }
        this.handleSubjectAreas();
        clearTimeout(time);
      }, 100);
    },
    handleSubjectAreas() {
      let data = [
        {
          value: 50,
          name: "生物学"
        },
        {
          value: 30,
          name: "物理学"
        },
        {
          value: 24,
          name: "化学工程"
        },
        {
          value: 20,
          name: "天文学"
        },
        {
          value: 15,
          name: "地球科学"
        },
        {
          value: 8,
          name: "化学"
        },
        {
          value: 8,
          name: "冶金"
        },
        {
          value: 8,
          name: "机械"
        },
        {
          value: 8,
          name: "数学"
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: "",
          a: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        },
        {
          value: 5,
          name: ""
        }
      ];
      let total = 0;

      data.forEach(item => {
        total = total + item.value;
      });

      let labelLine = {
        // normal: {
        length2: 0.5,
        lineStyle: {
          color: "#6f6f6f"
        }
        // }
      };
      data = data.map(item => {
        item.labelLine = {
          normal: {
            show: item.value / total > 0.03,
            length2: 0.5,
            lineStyle: {
              color: "#6f6f6f"
            }
          },
          emphasis: {
            show: item.value / total > 0.3
          }
        };
        return item;
      });
      // console.log(data);

      var myChart = this.$echarts.init(this.$refs.mySubsidizeChart),
        _this = this;
      myChart.showLoading();
      let option = {
        color: [
          "#899ab3",
          "#9eaec7",
          "#627796",
          "#89a4b3",
          "#9dcecf",
          "#9fb898",
          "#a698b8",
          "#dbcfb4",
          "#dbbab4",
          "#d79494",
          "#8b9eb9",
          "#b6dbe7",
          "#7a779c",
          "#89c3db",
          "#db89ab",
          "#dbce89",
          "#536689",
          "#6ccdaa",
          "#c9e0fd",
          "#b5937b",
          "#89b3b3"
        ],
        tooltip: {
          trigger: "item",
          formatter: function(param) {
            return param.marker + param.name + "：" + param.value + "<br>";
          }
        },
        series: [
          {
            name: "",
            type: "pie",
            radius: "62%",
            center: ["48%", "50%"],
            label: {
              formatter: function(params) {
                // console.log(params);

                if (params.percent > 3) {
                  return params.data.name + params.percent + "%";
                } else {
                  return "";
                }
              },
              borderColor: "#6f6f6f",
              borderWidth: 1,
              color: "#6f6f6f",
              fontSize: 10,
              height: 16,
              lineHeight: 16
            },

            data
          }
        ]
      };
      myChart.setOption(option, true);
      myChart.hideLoading();
      var that = this;
      myChart.on("click", function(params) {
        that.colorVal = params.color;
        that.handleClickAreasCharts();
      });
    },
    handleClickAreasCharts() {
      var myChart = this.$echarts.init(this.$refs.clickAreasChart);
      // console.log(this.colorVal);
      var dataVal = [
        {
          value: 50,
          name: "生物学"
        },
        {
          value: 30,
          name: "物理学"
        },
        {
          value: 24,
          name: "化学工程"
        },
        {
          value: 20,
          name: "天文学"
        },
        {
          value: 15,
          name: "地球科学"
        },
        {
          value: 8,
          name: "化学"
        }
      ];
      var newDataval = [];
      let jange = 1 / dataVal.length;
      dataVal.forEach((item, i) => {
        newDataval.push({
          value: item.value,
          name: item.name,
          itemStyle: {
            color: this.colorVal,
            opacity: (dataVal.length - i) * jange
          }
        });
      });
      // console.log(newDataval);
      let option = {
        tooltip: {
          trigger: "item",
          formatter: function(param) {
            return param.marker + param.name + "：" + param.value + "<br>";
          }
        },
        series: [
          {
            name: "",
            type: "pie",
            radius: "40%",
            center: ["50%", "50%"],
            label: {
              formatter: function(params) {
                if (params.percent > 3) {
                  return params.data.name + params.percent + "%";
                }
              },
              borderColor: "#6f6f6f",
              borderWidth: 1,
              color: "#6f6f6f",
              fontSize: 10,
              height: 14,
              lineHeight: 14
            },
            labelLine: {
              normal: {
                show: false,
                length2: 0,
                lineStyle: {
                  color: "#6f6f6f"
                }
              },
              emphasis: {
                show: true
              }
            },
            data: newDataval
          }
        ]
      };
      myChart.setOption(option);
      myChart.hideLoading();
    }
  }
};
</script>

<style lang="less" scoped>
.areas {
  width: 100%;
  height: 100%;
  padding: 20px;
  .titleDiv {
    height: 22px;
    .titleName {
      float: left;
      font-size: 20px;
      line-height: 22px;
      color: #191919;
      font-weight: 600;
    }
    .operating {
      float: right;
      span {
        display: inline-block;
        width: 22px;
        height: 22px;
        line-height: 22px;
        background: #d3d6dd;
        text-align: center;
        margin-right: 4px;
        font-weight: bold;
        color: #8f949f;
      }
      .chartActive {
        background: #ff3925;
        color: #fff;
      }
    }
  }
  .areasCharts {
    width: 100%;
    height: 310px;
    border: 1px solid #d3d6dd;
    margin-top: 30px;
    .areasChart {
      float: left;
      width: 55%;
      height: 100%;
    }
    .clickAreasChart {
      width: 45%;
      height: 100%;
      overflow: hidden;
    }
  }
  #subjectAreasList {
    margin-top: 20px;
    width: 100%;
    // height: 00px;
    border: 1px solid #ccc;
    table {
      width: 100%;
      thead {
        tr {
          height: 35px;
          line-height: 0px;
          th {
            font-size: 12px;
            width: 10%;
            text-align: center;
          }
        }
      }
      tbody {
        tr {
          border-top: 1px solid #ccc;
          height: 35px;
          line-height: 0px;
          td {
            width: 10%;
            text-align: center;
          }
        }
      }
    }
  }
  .fullFcreen {
    position: absolute;
    top: 40px;
    left: 20px;
    width: 1370px;
    height: 91%;
    padding: 5%;
    background: #fff;
    z-index: 2;
    .areasCharts {
      border: none;
    }
    .bounce-enter-active {
      animation: bounce-in 6s;
    }
    .bounce-leave-active {
      animation: bounce-in 6s reverse;
    }
    @keyframes bounce-in {
      0% {
        transform: scale(0);
      }
      50% {
        transform: scale(1.5);
      }
      100% {
        transform: scale(1);
      }
    }
    .subsidizeList {
      width: 100%;
    }
     .areasCharts {
    width: 100%;
    height: 100%;
    margin-top: 30px;
    .areasChart {
      float: left;
      width: 55%;
      height: 100%;
    }
    .clickAreasChart {
      width: 45%;
      height: 100%;
      overflow: hidden;
    }
  }
    #subjectAreasList {
      margin-top: 20px;
      width: 100%;
      // height: 00px;
      border: 1px solid #ccc;
      table {
        width: 100%;
        thead {
          tr {
            height: 60px;
            line-height: 0px;
            th {
              font-size: 12px;
              width: 10%;
              text-align: center;
            }
          }
        }
        tbody {
          tr {
            border-top: 1px solid #ccc;
            height: 80px;
            line-height: 0px;
            td {
              width: 10%;
              text-align: center;
            }
          }
        }
      }
    }
  }
}
</style>