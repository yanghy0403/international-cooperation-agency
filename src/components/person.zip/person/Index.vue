<template>
  <div class="International-talents">
    <!-- 左侧 -->
    <div class="fl-l">
      <div class="fl-logo">
        <img src="../../assets/images/国际人才/页面固定内容/logo.png" alt />
        <p>中国科学院国际合作</p>
        <p>数据汇聚于分析平台</p>
      </div>
      <div class="fl-content">
        <div class="titleName">国际人才</div>
        <div class="fl-tabs">
          <p @click="cur=0" :class="{active:cur==0}">按专题</p>
          <p @click="cur=1" :class="{active:cur==1}">按身份</p>
        </div>
        <div class="fl-info" v-show="cur==0">
          <ul>
            <li>
              <span>人才交流</span>
              <p v-for="(item,i) in topicList1" :key="i">{{item.value}}</p>
            </li>
            <li>
              <span>奖学金计划</span>
              <p>CAS-TWAS院长奖学金</p>
              <p>‘一带一路’硕士生奖</p>
              <p>ANSO奖学金</p>
            </li>
            <li>
              <span>国家/院级奖项</span>
              <p>中科院国际合作奖</p>
              <p>国家国际科技合作奖</p>
              <p>青年科学家国际合作伙伴奖</p>
              <p>中国政府‘友谊奖’</p>
            </li>
          </ul>
        </div>
        <div class="fl-info" v-show="cur==1">
          <ul>
            <li>
              <span>全体人员</span>
              <p>概览</p>
            </li>
            <li>
              <span>科研人员</span>
              <p>全职人员(含博士后)</p>
              <p>短期访问人员(&lt;1月/年)</p>
              <p>客座/兼职人员</p>
            </li>
            <li>
              <span>学生</span>
              <p>博士</p>
              <p>硕士</p>
            </li>
          </ul>
        </div>
      </div>
      <div class="fl-btm" @click="handleClose">
        <div class="iconfontClose">
          <i class="iconfont icon-fanhui"></i>
        </div>
        <div class="closeName">返回首页</div>
      </div>
    </div>
    <!-- 右侧 -->
    <div class="fr-r">
      <!-- 卷轴 -->
      <div @click="handleOpenUp" class="fr-reel-close">
        <div class="right-icon iconfont icon-shuangjiantouyou"></div>
      </div>
      <!-- 按专题 -->
      <transition>
        <div class="fr-reel" v-if="cur==0" v-show="isSlide">
          <div class="reel-header">
            <div class="reel-tabs">
              <p @click="mode=0" :class="{modeActive:mode==0}">自由模式</p>
              <p @click="mode=1" :class="{modeActive:mode==1}">条件模式</p>
              <div class="lock">
                <img v-if="mode==0" src="../../assets/images/国际人才/自由模式示意符.png" alt />
                <img
                  style="width:14px;height: 17px"
                  v-else
                  src="../../assets/images/国际人才/条件模式示意符.png"
                  alt
                />
              </div>
            </div>
            <div class="reel-filterCondition">
              <ul>
                <li>
                  <!-- 全年份
                  <i class="iconfont icon-iconfontjiantou"></i>-->
                  <!-- <el-date-picker
                    v-model="time"
                    type="year"
                    align="right"
                    unlink-panels
                    range-separator="-"
                    start-placeholder="全年份"
                    end-placeholder=""
                    :picker-options="pickerOptions"
                  ></el-date-picker>-->
                </li>
                <li>
                  <!-- 大洲 -->
                  <!-- <i class="iconfont icon-iconfontjiantou"></i> -->
                  <el-select v-model="continentSelect" filterable clearable placeholder="大洲">
                    <el-option
                      v-for="(item,i) in continentData"
                      :key="i"
                      :label="item.name"
                      :value="item.name"
                    ></el-option>
                  </el-select>
                </li>
                <li>
                  <!-- 国家
                  <i class="iconfont icon-iconfontjiantou"></i>-->
                  <el-select v-model="countriesSelect" filterable clearable placeholder="国家">
                    <el-option
                      v-for="(item,i) in countriesData"
                      :key="i"
                      :label="item.name"
                      :value="item.name"
                    ></el-option>
                  </el-select>
                </li>
                <li>
                  <!-- 城市
                  <i class="iconfont icon-iconfontjiantou"></i>-->
                  <el-select v-model="citySelect" filterable clearable placeholder="城市">
                    <el-option
                      v-for="(item,i) in subjectData"
                      :key="i"
                      :label="item.name"
                      :value="item.name"
                    ></el-option>
                  </el-select>
                </li>
                <li>
                  <!-- 学科
                  <i class="iconfont icon-iconfontjiantou"></i>-->
                  <el-select v-model="subjectSelect" filterable clearable placeholder="学科">
                    <el-option
                      v-for="(item,i) in subjectData"
                      :key="i"
                      :label="item.name"
                      :value="item.name"
                    ></el-option>
                  </el-select>
                </li>
                <li>
                  <!-- 人员类别
                  <i class="iconfont icon-iconfontjiantou"></i>-->
                  <el-select v-model="personTypeSelect" filterable clearable placeholder="人员类别">
                    <el-option
                      v-for="(item,i) in personTypeData"
                      :key="i"
                      :label="item.name"
                      :value="item.name"
                    ></el-option>
                  </el-select>
                </li>
              </ul>
            </div>
            <div class="reel-filterBtn">筛选</div>
            <div class="reel-empty iconfont icon-fanhui1"></div>
            <div class="reel-DownloadAll iconfont icon-xiazai"></div>
          </div>
          <div class="reel-center">
            <div class="reel-legend">
              <TopicSubsidize :data="TopicFounding" />
            </div>
            <div class="reel-legend">
              <TopicSubjectAreas :data="TopicSubject" />
            </div>
          </div>
          <div class="reel-botton">
            <TopicGlobalMap />
          </div>
          <div @click="handleShutdown" class="left-icon iconfont icon-shuangjiantouzuo"></div>
        </div>
      </transition>
      <!-- 按身份 -->
      <transition>
        <div class="fr-reel" v-if="cur==1" v-show="isSlide">
          <div class="reel-header">
            <div class="reel-tabs">
              <p @click="mode=0" :class="{modeActive:mode==0}">自由模式</p>
              <p @click="mode=1" :class="{modeActive:mode==1}">条件模式</p>
              <div class="lock">
                <img src="../../assets/images/国际人才/自由模式示意符.png" alt />
              </div>
            </div>
            <div class="reel-filterCondition">
              <ul>
                <li>
                  全年份
                  <i class="iconfont icon-iconfontjiantou"></i>
                </li>
                <li>
                  大洲
                  <i class="iconfont icon-iconfontjiantou"></i>
                </li>
                <li>
                  国家
                  <i class="iconfont icon-iconfontjiantou"></i>
                </li>
                <li>
                  城市
                  <i class="iconfont icon-iconfontjiantou"></i>
                </li>
                <li>
                  学科
                  <i class="iconfont icon-iconfontjiantou"></i>
                </li>
              </ul>
            </div>
            <div class="reel-filterBtn">筛选</div>
            <div class="reel-empty iconfont icon-fanhui1"></div>
            <div class="reel-DownloadAll iconfont icon-xiazai"></div>
          </div>
          <div class="reel-center">
            <div class="reel-legend">
              <IdentitySubsidize />
            </div>
            <div class="reel-legend">
              <IdentitySubjectAreas />
            </div>
          </div>
          <div class="reel-botton">
            <IdentityGlobalMap />
          </div>
          <div @click="handleShutdown" class="left-icon iconfont icon-shuangjiantouzuo"></div>
        </div>
      </transition>
      <!-- 底层列表 -->
      <div class="personList">
        <!-- 面包屑 -->
        <div class="crumbs">国际人才/按专题分类/人才交流/国际人才计划</div>
        <!-- 头部导航 -->
        <div class="person-header">
          <h3>国际人才计划</h3>
          <ul class="condition-query">
            <li>
              全年份
              <i class="icons iconfont icon-iconfontjiantou"></i>
            </li>
            <li>
              大洲
              <i class="icons iconfont icon-iconfontjiantou"></i>
            </li>
            <li>
              国家
              <i class="icons iconfont icon-iconfontjiantou"></i>
            </li>
            <li>
              城市
              <i class="icons iconfont icon-iconfontjiantou"></i>
            </li>
            <li>
              学科
              <i class="icons iconfont icon-iconfontjiantou"></i>
            </li>
            <li>
              人员类别
              <i class="icons iconfont icon-iconfontjiantou"></i>
            </li>
          </ul>
          <div class="personSearchBTN">筛选</div>
          <div class="DownloadList iconfont icon-xiazai" @click="handlDownloadExcel"></div>
          <input class="personInput" placeholder="请输入要检索人员姓名" type="text" />
          <div class="login">
            <img src="../../assets/images/国际人才/页面固定内容/用户按钮-内页版-默认状态.png" alt />
            <p>登录/注册</p>
          </div>
        </div>
        <!-- tab切换 -->
        <div class="listTabs">
          <span @click="listCur=0" :class="{listActive:listCur==0}" class="iconfont icon-liebiao1"></span>
          <span
            @click="listCur=1"
            :class="{listActive:listCur==1}"
            style="font-size: 14px"
            class="iconfont icon-liebiao"
          ></span>
          <label>总支持人数30,000，来自213个国家</label>
        </div>
        <!-- 列表 -->
        <div v-show="listCur==0" class="arrayList">
          <ul>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span
                @click="handleView(1)"
                :class="['view1','view2']"
                class="view iconfont icon-liulan"
              ></span>
              <div class="personName">李斯特</div>
              <div class="personCountry">中国</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>昆明植物研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>西班牙莱里达大学</span>
              </div>
              <div class="personInfo" v-show="isPersonInfo">
                <table class="table1">
                  <thead>
                    <tr>
                      <th width="15%">年度</th>
                      <th width="30%">项目编号</th>
                      <th width="30%">推荐单位</th>
                      <th width="25%">单位编号</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>2018</td>
                      <td>2018VBA0004</td>
                      <td>昆明植物研究所</td>
                      <td>151853</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table2">
                  <thead>
                    <tr>
                      <th width="40%">姓名</th>
                      <th width="20%">国际</th>
                      <th width="20%">所属洲</th>
                      <th width="20%">出生日期</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Shahram Khali</td>
                      <td>伊朗</td>
                      <td>亚洲</td>
                      <td>1970/02/03</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table3">
                  <thead>
                    <tr>
                      <th width="25%">国外单位</th>
                      <th width="25%">国家</th>
                      <th width="25%">英文一级</th>
                      <th width="25%">中文一级</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>德黑蓝大学</td>
                      <td>伊朗</td>
                      <td>Unversity</td>
                      <td>德黑蓝大学</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table4">
                  <thead>
                    <tr>
                      <th width="20%">城市</th>
                      <th width="25%">专业</th>
                      <th width="30%">职位及职务</th>
                      <th width="25%">中方合作者</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>德黑蓝</td>
                      <td>地理学</td>
                      <td>副教授</td>
                      <td>张凡</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table5">
                  <thead>
                    <tr>
                      <th width="17%">类别</th>
                      <th width="27%">是否延续项目</th>
                      <th width="27%">计划来华时长</th>
                      <th width="29%">批复金额(万元)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>访问学者</td>
                      <td>是</td>
                      <td>4</td>
                      <td>15.5</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span @click="handleView(2)" class="view iconfont icon-liulan"></span>
              <div class="personName">Tamer AbdelmakSOUD-Mohamed Tolba</div>
              <div class="personCountry">伊朗</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>青藏高原研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>德黑兰大学自然资源学院</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">李斯特</div>
              <div class="personCountry">中国</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>昆明植物研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>西班牙莱里达大学</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">Tamer AbdelmakSOUD-Mohamed Tolba</div>
              <div class="personCountry">伊朗</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>青藏高原研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>德黑兰大学自然资源学院</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span @click="handleView(5)" class="view iconfont icon-liulan"></span>
              <div class="personName">李斯特</div>
              <div class="personCountry">中国</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>昆明植物研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>西班牙莱里达大学</span>
              </div>
              <div class="personInfo" v-show="isPersonInfo">
                <table class="table1">
                  <thead>
                    <tr>
                      <th width="15%">年度</th>
                      <th width="30%">项目编号</th>
                      <th width="30%">推荐单位</th>
                      <th width="25%">单位编号</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>2018</td>
                      <td>2018VBA0004</td>
                      <td>昆明植物研究所</td>
                      <td>151853</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table2">
                  <thead>
                    <tr>
                      <th width="40%">姓名</th>
                      <th width="20%">国际</th>
                      <th width="20%">所属洲</th>
                      <th width="20%">出生日期</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Shahram Khali</td>
                      <td>伊朗</td>
                      <td>亚洲</td>
                      <td>1970/02/03</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table3">
                  <thead>
                    <tr>
                      <th width="25%">国外单位</th>
                      <th width="25%">国家</th>
                      <th width="25%">英文一级</th>
                      <th width="25%">中文一级</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>德黑蓝大学</td>
                      <td>伊朗</td>
                      <td>Unversity</td>
                      <td>德黑蓝大学</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table4">
                  <thead>
                    <tr>
                      <th width="20%">城市</th>
                      <th width="25%">专业</th>
                      <th width="30%">职位及职务</th>
                      <th width="25%">中方合作者</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>德黑蓝</td>
                      <td>地理学</td>
                      <td>副教授</td>
                      <td>张凡</td>
                    </tr>
                  </tbody>
                </table>
                <table class="table5">
                  <thead>
                    <tr>
                      <th width="17%">类别</th>
                      <th width="27%">是否延续项目</th>
                      <th width="27%">计划来华时长</th>
                      <th width="29%">批复金额(万元)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>访问学者</td>
                      <td>是</td>
                      <td>4</td>
                      <td>15.5</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">Tamer AbdelmakSOUD-Mohamed Tolba</div>
              <div class="personCountry">伊朗</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>青藏高原研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>德黑兰大学自然资源学院</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">李斯特</div>
              <div class="personCountry">中国</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>昆明植物研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>西班牙莱里达大学</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">Tamer AbdelmakSOUD-Mohamed Tolba</div>
              <div class="personCountry">伊朗</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>青藏高原研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>德黑兰大学自然资源学院</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">李斯特</div>
              <div class="personCountry">中国</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>昆明植物研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>西班牙莱里达大学</span>
              </div>
            </li>
            <li>
              <img src="../../assets/images/国际人才/默认头像无头像状态.png" alt />
              <span class="view iconfont icon-liulan"></span>
              <div class="personName">Tamer AbdelmakSOUD-Mohamed Tolba</div>
              <div class="personCountry">伊朗</div>
              <div class="line"></div>
              <div class="personSpecialty">教授·计算机科学技术</div>
              <div class="CHunit">
                <label>推荐单位：</label>
                <span>青藏高原研究所</span>
              </div>
              <div class="ENunit">
                <label>国外单位：</label>
                <span>德黑兰大学自然资源学院</span>
              </div>
            </li>
          </ul>
        </div>
        <div v-show="listCur==1" class="tableList">
          <table>
            <thead>
              <tr>
                <th>姓名</th>
                <th>国际</th>
                <th>职务/职位</th>
                <th>专业领域</th>
                <th>推荐单位</th>
                <th>国外工作单位</th>
                <th>类别</th>
                <th>信息预览</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>李斯特</td>
                <td>中国</td>
                <td>博士后</td>
                <td>生物学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>访问学者</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>Tamer Abdelmaksoud</td>
                <td>埃及</td>
                <td>博士后</td>
                <td>物理学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>教授</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>李斯特</td>
                <td>中国</td>
                <td>博士后</td>
                <td>生物学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>访问学者</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>Tamer Abdelmaksoud</td>
                <td>埃及</td>
                <td>博士后</td>
                <td>物理学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>教授</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>李斯特</td>
                <td>中国</td>
                <td>博士后</td>
                <td>生物学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>访问学者</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>Tamer Abdelmaksoud</td>
                <td>埃及</td>
                <td>博士后</td>
                <td>物理学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>教授</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>李斯特</td>
                <td>中国</td>
                <td>博士后</td>
                <td>生物学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>访问学者</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>Tamer Abdelmaksoud</td>
                <td>埃及</td>
                <td>博士后</td>
                <td>物理学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>教授</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>李斯特</td>
                <td>中国</td>
                <td>博士后</td>
                <td>生物学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>访问学者</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
              <tr>
                <td>Tamer Abdelmaksoud</td>
                <td>埃及</td>
                <td>博士后</td>
                <td>物理学</td>
                <td>中国科学院</td>
                <td>伊利诺伊学院</td>
                <td>教授</td>
                <td class="iconfont icon-liulan"></td>
                <td>
                  <div class="access">访问主页</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="pagination">
          <el-pagination background layout="prev, pager, next" :total="1000"></el-pagination>
        </div>
        <div class="record-info">
          <img src="../../assets/images/国际人才/页面固定内容/事业单位标志-内页统一样式版.png" alt />
          <span>中国科学院计算机网络信息中心</span>
          <span class="line">|</span>
          <span>备案编号:京ICP备0900008-26</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// 专题
import TopicSubsidize from "./modules/TopicSubsidize"; // 历年资助情况
import TopicSubjectAreas from "./modules/TopicSubjectAreas"; // 学科领域分布
import TopicGlobalMap from "./modules/TopicGlobalMap"; // 全球地域分布
// 身份
import IdentitySubsidize from "./modules/IdentitySubsidize "; // 历年人员数量
import IdentitySubjectAreas from "./modules/IdentitySubjectAreas"; // 学科领域分布
import IdentityGlobalMap from "./modules/IdentityGlobalMap";
export default {
  components: {
    TopicSubsidize,
    TopicSubjectAreas,
    TopicGlobalMap,
    IdentitySubsidize,
    IdentitySubjectAreas,
    IdentityGlobalMap
  },
  data() {
    return {
      cur: 0,
      listCur: 0,
      mode: 0,
      isPersonInfo: false,
      isShow: true,
      isSlide: true,
      nowPage: "0", // 当前页码
      pageSize: "10", // 每页显示条数
      source: "internationalPerson", // 类型
      continentData: [], // 大洲
      TopicFounding: [],
      TopicSubject: [],
      continentSelect: "",
      countriesSelect: "",
      subjectSelect: "",
      personTypeSelect: "",
      countriesData: [], //  国家
      subjectData: [], // 学科
      personTypeData: [], // 人员类别
      query_EQ_subject_name: null,
      time: "",
      topicList1: [
        {
          value: "国际人才计划"
        }
      ],
      topicList2: [
        {
          value: "CAS-TWAS院长奖学金"
        },
        {
          value: "‘一带一路’硕士生奖"
        },
        {
          value: "‘ANSO奖学金"
        }
      ],
      topicList3: [
        {
          value: "CAS-中科院国际合作奖"
        },
        {
          value: "国家国际科技合作奖"
        },
        {
          value: "青年科学家国际合作伙伴奖"
        },
        {
          value: "中国政府‘友谊奖’"
        }
      ]
    };
  },
  watch: {
    countriesSelect(val) {
      console.log(val);
    }
  },
  mounted() {
    this.handleContinent();
    this.handleTopicSearch();
    this.handleCountry();
    this.handleSubject();
    this.handlePersonType();
  },
  methods: {
    handleClose() {
      this.$router.push({ path: "/" });
    },
    // 关闭卷轴
    handleShutdown() {
      this.isSlide = false;
    },
    handleOpenUp() {
      this.isSlide = true;
    },
    handleView(val) {
      if (this.isPersonInfo == false) {
        this.isPersonInfo = true;
      } else {
        this.isPersonInfo = false;
      }
    },
    // 大洲
    handleContinent() {
      this.axios.get("/international/topic/continentList").then(res => {
        if (res.data.code == 200) {
          var data = res.data.data;
          this.continentData = data.map(item => {
            return {
              name: item
            };
          });
        }
      });
    },
    // 国家
    handleCountry() {
      this.axios.get("/index/country/autoTip").then(res => {
        // console.log(res);
        if (res.data.code == 200) {
          var data = res.data.data.name;
          var countries = res.data.data.countries;
          this.countriesData = data.map(item => {
            return {
              name: item
            };
          });
        }
      });
    },
    handleCity() {
      this.axios
        .get("/index/city/autoTip", {
          params: { query_EQ_cityZhName: this.query_EQ_cityZhName }
        })
        .then(res => {
          if (res.data.code == 200) {
            this;
          }
        });
    },
    // 学科分类
    handleSubject() {
      this.axios
        .get("/index/subject/autoTip", {
          params: { query_EQ_subject_name: this.query_EQ_subject_name }
        })
        .then(res => {
          if (res.data.code == 200) {
            var data = res.data.data.name;
            this.subjectData = data.map(item => {
              return {
                name: item
              };
            });
          }
        });
    },
    // 人员类别
    handlePersonType() {
      this.axios.get("/international/topic/personType").then(res => {
        if (res.data.code == 200) {
          var data = res.data.data;
          this.personTypeData = data.map(item => {
            return {
              name: item
            };
          });
        }
      });
    },
    // 按专题查询
    handleTopicSearch() {
      this.axios
        .get("/international/topic/internationalPerson", {
          params: {
            nowPage: this.nowPage,
            pageSize: this.pageSize,
            source: this.source
          }
        })
        .then(res => {
          if (res.data.code == 200) {
            // 历年资助情况
            this.TopicFounding = res.data.data.founding;
            // 学科分类
            this.TopicSubject = res.data.data.subject;
          }
        });
    },
    // 按身份查询
    // handleIdentitySearch () {
    //   this.axios
    //     .get(
    //       "/international/topic/personIdentity",{params: {nowPage: this.nowPage,pageSize: this.pageSize,source: this.source}})
    //     .then(res => {
    //       console.log(res);
    //       if(res.data.code == 200) {
    //         // 历年资助情况
    //         this.TopicFounding = res.data.data.founding
    //         // 学科分类
    //         this.TopicSubject = res.data.data.subject
    //       }
    //     });
    // }
    // 列表下载
    handlDownloadExcel() {
      this.axios
        .get("/international/topic/export/person", {
          params: { nowPage: this.nowPage, pageSize: this.pageSize }
        })
        .then(res => {
          const link = document.createElement("a");
          let blob = new Blob([res.data], { type: "application/vnd.ms-excel" });
          link.style.display = "none";
          link.href = URL.createObjectURL(blob);

          // link.download = res.headers['content-disposition'] //下载后文件名
          link.download = data.fileName; //下载的文件名
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        });
    }
  }
};
</script>

<style lang="less" scoped>
.International-talents {
  width: 100%;
  height: 100%;
  overflow: hidden;
  .fl-l {
    background: url("../../assets/images/国际人才/页面固定内容/导航栏底纹.png")
      no-repeat;
    background-size: 100% 100%;
    float: left;
    width: 16%;
    height: 100%;
    background-image: linear-gradient(#1f2e45, #1f2e45),
      linear-gradient(#ffffff, #ffffff);
    // background-blend-mode: normal, normal;
    .fl-logo {
      margin-left: 40px;
      padding-top: 40px;
      img {
        float: left;
        margin-right: 6px;
        width: 50px;
        height: 50px;
      }
      p {
        font-size: 17px;
        color: #fff;
      }
    }
    .fl-content {
      margin-left: 40px;
      .titleName {
        margin-top: 124px;
        font-size: 46px;
        // font-weight: bold;
        font-stretch: normal;
        color: #ff3925;
        font-family: PingFangSC-Light;
      }
      .fl-tabs {
        overflow: hidden;
        margin-top: 40px;
        p {
          float: left;
          width: 100px;
          height: 30px;
          font-size: 14px;
          line-height: 30px;
          text-align: center;
          color: #1f2e45;
          cursor: pointer;
          background-image: linear-gradient(#777d88, #777d88),
            linear-gradient(#ffffff, #ffffff);
          background-blend-mode: normal, normal;
        }
        .active {
          color: #fff;
          background-image: linear-gradient(#ff3a25, #ff3a25),
            linear-gradient(#292929, #292929);
          background-blend-mode: normal, normal;
        }
      }
      .fl-info {
        margin-top: 30px;
        ul {
          li {
            margin-bottom: 20px;
            span {
              color: #49586e;
              font-size: 12px;
              line-height: 30px;
            }
            p {
              font-size: 14px;
              color: #d3d3d3;
              line-height: 30px;
              cursor: pointer;
            }
            p:hover {
              color: #ff3a25;
            }
          }
        }
      }
    }
    .fl-btm {
      cursor: pointer;
      width: 120px;
      position: fixed;
      left: 40px;
      bottom: 40px;
      .iconfontClose {
        float: left;
        width: 50px;
        height: 50px;
        border: 3px solid #fff;
        border-radius: 50px;
        text-align: center;
        margin-right: 12px;
        i {
          color: #fff;
          font-size: 18px;
          line-height: 44px;
        }
      }
      .closeName {
        color: #fff;
        line-height: 50px;
        font-size: 14px;
        font-weight: bold;
      }
    }
    .fl-btm:hover {
      .iconfontClose {
        border: 3px solid #ff3a25;
        i {
          color: #ff3a25;
        }
      }
      .closeName {
        color: #ff3a25;
      }
    }
  }
  .fr-r {
    width: 84%;
    height: 100%;
    position: relative;
    overflow: hidden;
    .fr-reel {
      position: fixed;
      left: 16%;
      top: 0;
      width: 76%;
      height: 100%;
      background: #e1e5ec;
      overflow: hidden;
      opacity: 0.97;
      z-index: 5;
      .v-enter,
      .v-leave-to {
        // opacity: 0;
        transform: translateX(100px);
      }
      .v-enter-active,
      .v-leave-active {
        transition: all 60s ease;
      }
      .reel-header {
        margin-left: 20px;
        margin-top: 40px;
        overflow: hidden;
        .reel-tabs {
          p {
            float: left;
            width: 80px;
            height: 40px;
            font-size: 14px;
            color: #737886;
            background: #d3d6dd;
            line-height: 40px;
            text-align: center;
            cursor: pointer;
          }
          p:first-child {
            border-top-left-radius: 9px;
            border-bottom-left-radius: 9px;
          }
          p:nth-child(2) {
            border-top-right-radius: 9px;
            border-bottom-right-radius: 9px;
          }
          .modeActive {
            background: #ff3a25;
            color: #fff;
          }
          .lock {
            float: left;
            line-height: 40px;
            margin-left: 8px;
            margin-right: 28px;
            img {
              width: 20px;
              height: 17px;
            }
          }
        }
        .reel-filterCondition {
          ul {
            li {
              position: relative;
              width: 158px;
              height: 40px;
              font-size: 14px;
              // border: solid 1px #d9dde4;
              border-right: none;
              // background: #fff;
              // color: #dcdcdc;
              float: left;
              line-height: 40px;
              text-align: center;
              i {
                position: absolute;
                top: 0;
                right: 9px;
              }
            }
            li:last-child {
              border-right: solid 1px #d9dde4;
            }
          }
        }
        .reel-filterBtn {
          float: left;
          width: 50px;
          height: 40px;
          background: #fff;
          border-radius: 10px;
          line-height: 40px;
          text-align: center;
          font-size: 14px;
          color: #dcdcdc;
          margin: 0 10px;
        }
        .reel-empty {
          float: left;
          width: 40px;
          height: 40px;
          background: #fff;
          border-radius: 10px;
          line-height: 40px;
          font-size: 20px;
          color: #8f949f;
          text-align: center;
        }
        .reel-DownloadAll {
          float: right;
          width: 40px;
          height: 40px;
          background: #fff;
          border-radius: 10px;
          line-height: 40px;
          font-size: 20px;
          color: #8f949f;
          text-align: center;
          margin-right: 70px;
        }
      }
      .reel-center {
        overflow: hidden;
        margin-left: 20px;
        margin-top: 10px;
        height: 41%;
        .reel-legend {
          float: left;
          width: 680px;
          height: 100%;
          background: #fff;
        }
        .reel-legend:first-child {
          margin-right: 10px;
        }
      }
      .reel-botton {
        width: 1370px;
        height: 44%;
        background: #fff;
        margin-left: 20px;
        margin-top: 10px;
      }
      .left-icon {
        position: absolute;
        right: 0;
        top: 50%;
        width: 40px;
        height: 100%;
        font-size: 20px;
      }
    }
    .fr-reel-close {
      display: none;
      float: left;
      width: 3%;
      height: 100%;
      background: #e1e5ec;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      .right-icon {
        font-size: 18px;
        text-align: center;
      }
    }
    .personList {
      float: left;
      width: 96%;
      height: 100%;
      padding: 2%;
      .crumbs {
        color: #a5a5a5;
        font-size: 12px;
      }
      .person-header {
        height: 60px;
        margin: 8px 0;
        h3 {
          float: left;
          font-size: 25px;
          font-stretch: normal;
          color: #ff3925;
          line-height: 60px;
        }
        .condition-query {
          display: flex;
          align-items: center;
          justify-content: center;
          float: left;
          height: 60px;
          margin-left: 130px;
          li {
            float: left;
            width: 119px;
            height: 40px;
            line-height: 40px;
            font-size: 14px;
            text-align: center;
            border: 1px solid #d9dde4;
            border-right: none;
            background: #e2e6ed;
          }
          li:last-child {
            border-right: 1px solid #d9dde4;
          }
        }
        .personSearchBTN {
          float: left;
          width: 50px;
          height: 40px;
          line-height: 40px;
          font-size: 14px;
          color: #727272;
          text-align: center;
          background: #e2e6ed;
          border-radius: 10px;
          margin-left: 10px;
          margin-top: 10px;
        }
        .DownloadList {
          float: left;
          width: 40px;
          height: 40px;
          background: #e2e6ed;
          line-height: 40px;
          text-align: center;
          font-size: 18px;
          margin: 10px 20px 0 10px;
        }
        .personInput {
          width: 250px;
          height: 40px;
          margin-top: 10px;
        }
        .login {
          float: right;
          width: 70px;
          text-align: center;
          img {
            margin-top: 3px;
            width: 24px;
            height: 29px;
          }
          p {
            margin-top: 12px;
            font-size: 14px;
            color: #727272;
          }
        }
      }
      .listTabs {
        span {
          display: inline-block;
          width: 22px;
          height: 22px;
          font-size: 12px;
          line-height: 22px;
          background: #d3d6dd;
          text-align: center;
          font-weight: bold;
          color: #8f949f;
        }
        .listActive {
          background: #ff3925;
          color: #fff;
        }
        label {
          font-size: 14px;
          color: #6f6f6f;
          margin-left: 12px;
        }
      }
      .arrayList {
        width: 100%;
        overflow: hidden;
        margin-top: 10px;
        ul {
          width: 100%;
          li {
            position: relative;
            float: left;
            width: 295px;
            height: 330px;
            border: 1px solid #d9dde4;
            border-right: none;
            overflow: hidden;
            text-align: center;
            overflow: initial;
            .view {
              position: absolute;
              top: 14px;
              right: 20px;
              color: #9c9ea0;
            }
            img {
              width: 80px;
              height: 80px;
              margin-top: 20px;
              margin-bottom: 14px;
            }
            .personName {
              width: 225px;
              height: 35px;
              margin: auto;
              font-size: 18px;
              color: #393939;
              // margin-top: 20px;
              line-height: 22px;
            }
            .personCountry {
              font-size: 14px;
              color: #393939;
              margin-top: 14px;
            }
            .line {
              width: 26px;
              height: 2px;
              background: #959595;
              margin: 22px auto 28px;
            }
            .personSpecialty,
            .CHunit,
            .ENunit {
              font-size: 12px;
              color: #959595;
              line-height: 24px;
            }
            .personInfo {
              position: absolute;
              top: 0;
              right: -295px;
              width: 295px;
              height: 330px;
              background: #627190;
              color: #fff;
              opacity: 0.98;
              z-index: 2;
              .table1 {
                margin-top: 28px;
              }
              .table1,
              .table2,
              .table3,
              .table4,
              .table5 {
                width: 285px;
                height: 50px;
                margin-bottom: 6px;
                margin-left: 6px;
                opacity: 0.98;
                background: #7583a1;
                text-align: center;
                tr:first-child {
                  border-bottom: 1px solid #5f6e8e;
                  color: #fff;
                  th,
                  td {
                    text-align: center;
                    height: 25px;
                    font-size: 12px;
                    -webkit-transform-origin-x: 0;
                    -webkit-transform: scale(0.8);
                    border-right: 1px solid #5f6e8e;
                  }
                }
              }
            }
          }
          li:nth-child(5),
          li:nth-child(10) {
            border-right: 1px solid #d9dde4;
            .personInfo {
              position: absolute;
              top: 0;
              right: 294px;
              width: 295px;
              height: 330px;
              background: #627190;
              color: #fff;
              opacity: 0.98;
              z-index: 2;
              .table1 {
                margin-top: 28px;
              }
              .table1,
              .table2,
              .table3,
              .table4,
              .table5 {
                width: 285px;
                height: 50px;
                margin-bottom: 6px;
                margin-left: 6px;
                opacity: 0.98;
                background: #7583a1;
                text-align: center;
                tr:first-child {
                  border-bottom: 1px solid #5f6e8e;
                  color: #fff;
                  th,
                  td {
                    text-align: center;
                    height: 25px;
                    font-size: 12px;
                    -webkit-transform-origin-x: 0;
                    -webkit-transform: scale(0.8);
                    border-right: 1px solid #5f6e8e;
                  }
                }
              }
            }
          }
          li:nth-child(1),
          li:nth-child(2),
          li:nth-child(3),
          li:nth-child(4),
          li:nth-child(5) {
            border-bottom: none;
          }
        }
      }
      .tableList {
        width: 100%;
        border: solid 1px #d9dde4;
        margin-top: 10px;
        table {
          width: 100%;
          thead {
            tr {
              height: 43px;
              line-height: 43px;
              font-size: 14px;
              color: #393939;
              border-bottom: 1px solid #d9dde4;
              th {
                width: 11%;
                text-align: center;
              }
            }
          }
          tbody {
            tr {
              height: 63px;
              line-height: 63px;
              width: 11%;
              font-size: 14px;
              color: #6f6f6f;
              border-bottom: 1px solid #d9dde4;
              td {
                text-align: center;
              }
              .access {
                width: 90px;
                height: 22px;
                line-height: 22px;
                background: #e2e6ed;
                border-radius: 10px;
                margin: auto;
                cursor: pointer;
              }
            }
            tr:last-child {
              border-bottom: none;
            }
          }
        }
      }
      .pagination {
        margin-top: 22px;
        float: right;
        /deep/ .el-pagination.is-background .el-pager li:not(.disabled).active {
          background-color: #ff3925;
          color: #fff;
        }
        /deep/ .el-pagination.is-background .el-pager li:not(.disabled):hover {
          color: #606266;
        }
        // /deep/ .el-pager li:hover {
        //   color: #fff;
        // }
      }
      .record-info {
        position: absolute;
        bottom: 23px;
        left: 21%;
        overflow: hidden;
        img {
          width: 12px;
          height: 16px;
          margin-right: 8px;
        }
        span {
          line-height: 16px;
          color: #a5a5a5;
          font-size: 12px;
        }
        .line {
          margin: 0 10px;
        }
      }
    }
  }
}
</style>